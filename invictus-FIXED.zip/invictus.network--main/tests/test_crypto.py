from invictus.crypto import (
    ADDRESS_LENGTH,
    ADDRESS_PREFIX,
    address_from_public_key,
    digest,
    generate_keypair,
    sign,
    verify,
)


def test_address_has_the_length_the_validator_expects():
    """Regression: ADDRESS_LENGTH and the constructed address must agree.

    These drifted apart once (the validator required 45 characters while
    addresses were 44), which rejected every transaction on the network.
    """
    _, public_key = generate_keypair()
    address = address_from_public_key(public_key)
    assert len(address) == ADDRESS_LENGTH
    assert address.startswith(ADDRESS_PREFIX)


def test_address_body_is_hexadecimal():
    _, public_key = generate_keypair()
    address = address_from_public_key(public_key)
    int(address[len(ADDRESS_PREFIX):], 16)


def test_address_is_deterministic():
    _, public_key = generate_keypair()
    assert address_from_public_key(public_key) == address_from_public_key(public_key)


def test_distinct_keys_give_distinct_addresses():
    _, first = generate_keypair()
    _, second = generate_keypair()
    assert address_from_public_key(first) != address_from_public_key(second)


def test_signature_round_trip():
    private_key, public_key = generate_keypair()
    signature = sign(private_key, b"payload")
    assert verify(public_key, signature, b"payload")


def test_verify_rejects_a_tampered_payload():
    private_key, public_key = generate_keypair()
    signature = sign(private_key, b"payload")
    assert not verify(public_key, signature, b"other payload")


def test_verify_rejects_another_keys_signature():
    private_key, _ = generate_keypair()
    _, other_public_key = generate_keypair()
    assert not verify(other_public_key, sign(private_key, b"payload"), b"payload")


def test_verify_rejects_malformed_signatures_without_raising():
    _, public_key = generate_keypair()
    assert not verify(public_key, "not-hex", b"payload")
    assert not verify(public_key, "", b"payload")


def test_digest_is_stable():
    assert digest(b"invictus") == digest(b"invictus")
    assert len(digest(b"invictus")) == 64
