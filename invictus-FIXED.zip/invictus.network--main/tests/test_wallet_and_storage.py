import json

import pytest

from invictus.config import NetworkConfig
from invictus.storage import NodeStorage
from invictus.wallet import Wallet


def test_a_wallet_round_trips_through_its_private_key():
    wallet = Wallet.create()
    restored = Wallet.from_private_key(wallet.export_private_key())
    assert restored.address == wallet.address
    assert restored.public_key == wallet.public_key


def test_an_encrypted_key_round_trips_with_the_same_password(monkeypatch):
    monkeypatch.setenv("INVICTUS_WALLET_PASSWORD", "correct horse battery staple")
    wallet = Wallet.create()
    exported = wallet.export_encrypted_private_key()
    assert exported.startswith("INV1$")
    assert Wallet.from_private_key(exported).address == wallet.address


def test_an_encrypted_key_will_not_open_with_the_wrong_password(monkeypatch):
    monkeypatch.setenv("INVICTUS_WALLET_PASSWORD", "first password")
    exported = Wallet.create().export_encrypted_private_key()
    monkeypatch.setenv("INVICTUS_WALLET_PASSWORD", "second password")
    with pytest.raises(ValueError):
        Wallet.from_private_key(exported)


def test_an_exported_key_does_not_contain_the_raw_private_key(monkeypatch):
    monkeypatch.setenv("INVICTUS_WALLET_PASSWORD", "a password")
    wallet = Wallet.create()
    assert wallet.export_private_key() not in wallet.export_encrypted_private_key()


def test_a_wallet_signs_what_it_can_verify():
    from invictus.crypto import verify

    wallet = Wallet.create()
    assert verify(wallet.public_key, wallet.sign(b"payload"), b"payload")


def test_chain_survives_a_save_and_load(tmp_path):
    storage = NodeStorage(tmp_path)
    blocks = [{"index": 0, "transactions": []}, {"index": 1, "transactions": []}]
    storage.save_chain(blocks)
    assert storage.load_chain() == blocks


def test_a_corrupt_chain_file_falls_back_to_the_backup(tmp_path):
    storage = NodeStorage(tmp_path)
    storage.save_chain([{"index": 0}])
    storage.save_chain([{"index": 0}, {"index": 1}])
    storage.chain_path.write_text("{ this is not json", encoding="utf-8")
    assert storage.load_chain() == [{"index": 0}]


def test_load_chain_returns_none_when_nothing_is_stored(tmp_path):
    assert NodeStorage(tmp_path).load_chain() is None


def test_a_wallet_key_file_is_not_world_readable(tmp_path):
    storage = NodeStorage(tmp_path)
    storage.save_wallet_key(Wallet.create().export_private_key())
    assert storage.wallet_path.stat().st_mode & 0o077 == 0


def test_a_stored_wallet_key_round_trips(tmp_path):
    storage = NodeStorage(tmp_path)
    wallet = Wallet.create()
    storage.save_wallet_key(wallet.export_private_key())
    assert Wallet.from_private_key(storage.load_wallet_key()).address == wallet.address


def test_network_config_loads_from_a_file(tmp_path):
    path = tmp_path / "network.json"
    path.write_text(
        json.dumps(
            {
                "network_id": "invictus-test",
                "chain_id": 42,
                "p2p_port": 1000,
                "rpc_port": 1100,
                "block_reward": 7,
                "bootstrap_peers": ["127.0.0.1:1000"],
                "genesis_timestamp": 5,
                "initial_balances": {"one1" + "a" * 40: 10},
            }
        ),
        encoding="utf-8",
    )
    config = NetworkConfig.load(path)
    assert config.network_id == "invictus-test"
    assert config.chain_id == 42
    assert config.bootstrap_peers == ("127.0.0.1:1000",)
    assert config.genesis_data()["timestamp"] == 5


def test_the_checked_in_mainnet_config_issues_nothing():
    """The mainnet profile is a launch artifact; issuance must stay at zero."""
    config = NetworkConfig.load("config/mainnet.json")
    assert config.network_id == "invictus-mainnet-1"
    assert config.block_reward == 0
    assert config.bootstrap_peers == ()
