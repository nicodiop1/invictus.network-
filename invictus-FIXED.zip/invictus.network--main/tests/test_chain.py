import pytest

from invictus.block import Block
from invictus.chain import Blockchain
from invictus.consensus import Consensus
from invictus.transaction import Transaction
from invictus.wallet import Wallet


@pytest.fixture
def wallets():
    return Wallet.create(), Wallet.create(), Wallet.create()


def mine(chain, validator, transactions):
    block = Block.create(len(chain.blocks), chain.latest.block_hash, transactions, validator)
    chain.add_block(block)
    return block


def test_a_new_chain_starts_at_genesis():
    chain = Blockchain()
    assert len(chain.blocks) == 1
    assert chain.latest.index == 0
    assert chain.latest.previous_hash == "0" * 64


def test_a_coinbase_block_credits_the_recipient(wallets):
    """Regression: no block could be added at all before the address-length fix."""
    miner, alice, _ = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    assert chain.balance(alice.address) == 100


def test_a_payment_moves_value_and_charges_the_fee(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    payment = Transaction.payment(alice, bob.address, 30, fee=1, nonce=chain.next_nonce(alice.address))
    mine(chain, miner, [payment])
    assert chain.balance(alice.address) == 69
    assert chain.balance(bob.address) == 30


def test_spending_more_than_the_balance_is_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 10)])
    overspend = Transaction.payment(alice, bob.address, 999, nonce=chain.next_nonce(alice.address))
    with pytest.raises(ValueError):
        mine(chain, miner, [overspend])


def test_the_fee_counts_against_the_balance(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 10)])
    exact_amount_but_no_room_for_fee = Transaction.payment(
        alice, bob.address, 10, fee=1, nonce=chain.next_nonce(alice.address)
    )
    with pytest.raises(ValueError):
        mine(chain, miner, [exact_amount_but_no_room_for_fee])


def test_replaying_a_transaction_is_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    payment = Transaction.payment(alice, bob.address, 10, nonce=chain.next_nonce(alice.address))
    mine(chain, miner, [payment])
    with pytest.raises(ValueError):
        mine(chain, miner, [payment])


def test_the_same_transaction_twice_in_one_block_is_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    payment = Transaction.payment(alice, bob.address, 10, nonce=chain.next_nonce(alice.address))
    with pytest.raises(ValueError):
        mine(chain, miner, [payment, payment])


def test_out_of_order_nonces_are_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    with pytest.raises(ValueError):
        mine(chain, miner, [Transaction.payment(alice, bob.address, 10, nonce=7)])


def test_two_coinbase_transactions_in_one_block_are_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    with pytest.raises(ValueError):
        mine(chain, miner, [Transaction(None, alice.address, 50), Transaction(None, bob.address, 50)])


def test_a_coinbase_after_a_payment_is_rejected(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    payment = Transaction.payment(alice, bob.address, 10, nonce=chain.next_nonce(alice.address))
    with pytest.raises(ValueError):
        mine(chain, miner, [payment, Transaction(None, miner.address, 50)])


def test_a_block_pointing_at_the_wrong_parent_is_rejected(wallets):
    miner, alice, _ = wallets
    chain = Blockchain()
    orphan = Block.create(1, "f" * 64, [Transaction(None, alice.address, 50)], miner)
    with pytest.raises(ValueError):
        chain.add_block(orphan)


def test_a_block_with_the_wrong_index_is_rejected(wallets):
    miner, alice, _ = wallets
    chain = Blockchain()
    wrong_index = Block.create(7, chain.latest.block_hash, [Transaction(None, alice.address, 50)], miner)
    with pytest.raises(ValueError):
        chain.add_block(wrong_index)


def test_a_tampered_block_fails_signature_validation(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    block = Block.create(1, chain.latest.block_hash, [Transaction(None, alice.address, 50)], miner)
    forged = Block(**{**block.to_dict(), "transactions": (Transaction(None, bob.address, 50),)})
    assert not forged.is_valid_signature()
    with pytest.raises(ValueError):
        chain.add_block(forged)


def test_consensus_can_restrict_who_produces_blocks(wallets):
    miner, alice, _ = wallets
    allowed = Blockchain(Consensus({miner.address}))
    mine(allowed, miner, [Transaction(None, alice.address, 50)])
    assert len(allowed.blocks) == 2

    stranger = Wallet.create()
    restricted = Blockchain(Consensus({miner.address}))
    with pytest.raises(ValueError):
        mine(restricted, stranger, [Transaction(None, alice.address, 50)])


def test_genesis_balances_are_honoured(wallets):
    _, alice, _ = wallets
    chain = Blockchain(genesis_data={"initial_balances": {alice.address: 500}})
    assert chain.balance(alice.address) == 500


def test_total_supply_counts_genesis_and_coinbase(wallets):
    miner, alice, _ = wallets
    chain = Blockchain(genesis_data={"initial_balances": {alice.address: 500}})
    mine(chain, miner, [Transaction(None, miner.address, 50)])
    assert chain.total_supply == 550


def test_a_chain_round_trips_through_dicts(wallets):
    miner, alice, bob = wallets
    chain = Blockchain()
    mine(chain, miner, [Transaction(None, alice.address, 100)])
    payment = Transaction.payment(alice, bob.address, 25, nonce=chain.next_nonce(alice.address))
    mine(chain, miner, [payment])

    restored = Blockchain.from_dicts(chain.to_dicts())
    assert len(restored.blocks) == len(chain.blocks)
    assert restored.balance(bob.address) == 25
    assert restored.latest.block_hash == chain.latest.block_hash
