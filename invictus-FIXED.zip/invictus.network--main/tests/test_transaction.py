import pytest

from invictus.transaction import Transaction
from invictus.wallet import Wallet


@pytest.fixture
def sender():
    return Wallet.create()


@pytest.fixture
def recipient():
    return Wallet.create()


def test_a_signed_payment_is_valid(sender, recipient):
    """Regression: this returned False for every payment ever created."""
    assert Transaction.payment(sender, recipient.address, 10).is_valid()


def test_a_coinbase_is_valid(recipient):
    """Regression: mining rewards were rejected, so no block could be produced."""
    assert Transaction(None, recipient.address, 50).is_valid()


def test_coinbase_is_recognised(recipient):
    assert Transaction(None, recipient.address, 50).is_coinbase()


def test_payment_is_not_coinbase(sender, recipient):
    assert not Transaction.payment(sender, recipient.address, 10).is_coinbase()


def test_payment_carries_sender_address_and_signature(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10)
    assert transaction.sender == sender.address
    assert transaction.signature is not None
    assert transaction.public_key == sender.public_key.hex()


@pytest.mark.parametrize("amount", [0, -1])
def test_non_positive_amounts_are_rejected(sender, recipient, amount):
    transaction = Transaction.payment(sender, recipient.address, 10)
    assert not Transaction(**{**transaction.to_dict(), "amount": amount}).is_valid()


def test_negative_fees_are_rejected(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10)
    assert not Transaction(**{**transaction.to_dict(), "fee": -1}).is_valid()


def test_coinbase_with_a_fee_is_rejected(recipient):
    assert not Transaction(None, recipient.address, 50, fee=1).is_valid()


def test_coinbase_carrying_a_signature_is_rejected(sender, recipient):
    signed = Transaction.payment(sender, recipient.address, 10)
    assert not Transaction(None, recipient.address, 50, signature=signed.signature).is_valid()


@pytest.mark.parametrize(
    "address",
    [
        "one1" + "a" * 39,          # too short
        "one1" + "a" * 41,          # too long
        "two1" + "a" * 40,          # wrong prefix
        "one1" + "z" * 40,          # not hexadecimal
        "",
    ],
)
def test_malformed_recipients_are_rejected(sender, address):
    transaction = Transaction.payment(sender, Wallet.create().address, 10)
    assert not Transaction(**{**transaction.to_dict(), "recipient": address}).is_valid()


def test_recipient_of_the_wrong_type_is_rejected(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10)
    assert not Transaction(**{**transaction.to_dict(), "recipient": None}).is_valid()


def test_tampering_with_the_amount_invalidates_the_signature(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10)
    forged = Transaction(**{**transaction.to_dict(), "amount": 1_000_000})
    assert not forged.is_valid()


def test_sender_that_does_not_match_the_public_key_is_rejected(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10)
    assert not Transaction(**{**transaction.to_dict(), "sender": recipient.address}).is_valid()


def test_negative_nonce_is_rejected(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10, nonce=0)
    assert not Transaction(**{**transaction.to_dict(), "nonce": -1}).is_valid()


def test_round_trips_through_a_dict(sender, recipient):
    transaction = Transaction.payment(sender, recipient.address, 10, fee=2, nonce=3)
    assert Transaction.from_dict(transaction.to_dict()) == transaction


def test_transaction_id_changes_with_content(sender, recipient):
    first = Transaction.payment(sender, recipient.address, 10, nonce=0)
    second = Transaction.payment(sender, recipient.address, 10, nonce=1)
    assert first.transaction_id != second.transaction_id
