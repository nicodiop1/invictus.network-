
const script=document.createElement("script");
script.src=chrome.runtime.getURL("inpage.js");
script.onload=()=>script.remove();
(document.head||document.documentElement).appendChild(script);

window.addEventListener("message",event=>{
  if(event.source!==window || event.data?.source!=="invictus-dapp") return;
  const {id,method,params}=event.data;
  const allowed=new Set(["CONNECT","STATUS","SIGN_MESSAGE","SIGN_TRANSACTION"]);
  if(!allowed.has(method)) return;

  chrome.runtime.sendMessage({type:method,...(params||{})},response=>{
    window.postMessage({source:"invictus-extension",id,response:response||{ok:false,error:"Extension unavailable"}},"*");
  });
});
