
(()=>{
  if(window.invictus?.isInvictus) return;
  let seq=0; const pending=new Map();

  function request(method,params={}){
    return new Promise((resolve,reject)=>{
      const id="invictus-"+Date.now()+"-"+(++seq);
      pending.set(id,{resolve,reject});
      window.postMessage({source:"invictus-dapp",id,method,params},"*");
      setTimeout(()=>{
        const p=pending.get(id); if(!p)return;
        pending.delete(id); reject(new Error("Invictus Wallet request timed out"));
      },60000);
    });
  }

  window.addEventListener("message",event=>{
    if(event.source!==window || event.data?.source!=="invictus-extension") return;
    const p=pending.get(event.data.id); if(!p)return;
    pending.delete(event.data.id);
    const r=event.data.response;
    r?.ok ? p.resolve(r.result) : p.reject(new Error(r?.error||"Invictus Wallet error"));
  });

  Object.defineProperty(window,"invictus",{value:{
    isInvictus:true,
    name:"Invictus Wallet V2",
    connect:()=>request("CONNECT"),
    status:()=>request("STATUS"),
    signMessage:(message)=>request("SIGN_MESSAGE",{message}),
    signTransaction:(transaction)=>request("SIGN_TRANSACTION",{transaction})
  },writable:false,configurable:false});

  window.dispatchEvent(new Event("invictus#initialized"));
})();
