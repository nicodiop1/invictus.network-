
const enc = new TextEncoder();

function bytesToB64(bytes){
  let s=""; for(const b of bytes) s += String.fromCharCode(b); return btoa(s);
}
function b64ToBytes(s){
  const raw=atob(s); return Uint8Array.from(raw,c=>c.charCodeAt(0));
}
async function deriveKey(password,salt){
  const base=await crypto.subtle.importKey("raw",enc.encode(password),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey(
    {name:"PBKDF2",salt,iterations:310000,hash:"SHA-256"},
    base,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]
  );
}
export async function encryptBytes(bytes,password){
  const salt=crypto.getRandomValues(new Uint8Array(16));
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await deriveKey(password,salt);
  const ct=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv},key,bytes));
  return {v:1,salt:bytesToB64(salt),iv:bytesToB64(iv),ct:bytesToB64(ct)};
}
export async function decryptBytes(vault,password){
  const salt=b64ToBytes(vault.salt),iv=b64ToBytes(vault.iv),ct=b64ToBytes(vault.ct);
  const key=await deriveKey(password,salt);
  return new Uint8Array(await crypto.subtle.decrypt({name:"AES-GCM",iv},key,ct));
}
export { bytesToB64, b64ToBytes };
