
import { encryptBytes, decryptBytes, bytesToB64, b64ToBytes } from "./crypto.js";
import { base58 } from "./base58.js";

let privateKey = null;
let publicKeyRaw = null;

async function createWallet(password){
  if(!password || password.length<8) throw new Error("Password must be at least 8 characters");

  const pair = await crypto.subtle.generateKey({name:"Ed25519"}, true, ["sign","verify"]);
  const pkcs8 = new Uint8Array(await crypto.subtle.exportKey("pkcs8", pair.privateKey));
  const rawPub = new Uint8Array(await crypto.subtle.exportKey("raw", pair.publicKey));
  const address = base58(rawPub);
  const vault = await encryptBytes(pkcs8,password);

  await chrome.storage.local.set({vault,address,publicKeyRaw:bytesToB64(rawPub)});
  privateKey = pair.privateKey;
  publicKeyRaw = rawPub;
  return {publicKey:address};
}

async function importWallet(pkcs8B64,password){
  if(!password || password.length<8) throw new Error("Password must be at least 8 characters");
  if(!pkcs8B64) throw new Error("Private key is required");

  const pkcs8 = b64ToBytes(pkcs8B64.trim());
  const key = await crypto.subtle.importKey("pkcs8",pkcs8,{name:"Ed25519"},true,["sign"]);

  // Derive public key by exporting JWK if supported.
  const jwk = await crypto.subtle.exportKey("jwk", key);
  if(!jwk.x) throw new Error("Could not derive public key");
  const rawPub = Uint8Array.from(atob(jwk.x.replace(/-/g,"+").replace(/_/g,"/").padEnd(Math.ceil(jwk.x.length/4)*4,"=")),c=>c.charCodeAt(0));
  const address = base58(rawPub);
  const vault = await encryptBytes(pkcs8,password);

  await chrome.storage.local.set({vault,address,publicKeyRaw:bytesToB64(rawPub)});
  privateKey = key;
  publicKeyRaw = rawPub;
  return {publicKey:address};
}

async function unlock(password){
  const {vault,publicKeyRaw:pub} = await chrome.storage.local.get(["vault","publicKeyRaw"]);
  if(!vault) throw new Error("No wallet found");
  const pkcs8 = await decryptBytes(vault,password);
  privateKey = await crypto.subtle.importKey("pkcs8",pkcs8,{name:"Ed25519"},false,["sign"]);
  publicKeyRaw = b64ToBytes(pub);
  const {address} = await chrome.storage.local.get("address");
  return {publicKey:address};
}

async function status(){
  const {vault,address} = await chrome.storage.local.get(["vault","address"]);
  return {exists:!!vault,locked:!privateKey,publicKey:address||null};
}

async function signMessage(message){
  if(!privateKey) throw new Error("Wallet is locked");
  const bytes = typeof message==="string" ? new TextEncoder().encode(message) : Uint8Array.from(message);
  const sig = new Uint8Array(await crypto.subtle.sign("Ed25519",privateKey,bytes));
  return {signature:Array.from(sig)};
}

chrome.runtime.onMessage.addListener((m,s,reply)=>{
  (async()=>{
    try{
      let result;
      if(m.type==="CREATE") result=await createWallet(m.password);
      else if(m.type==="IMPORT") result=await importWallet(m.privateKey,m.password);
      else if(m.type==="UNLOCK") result=await unlock(m.password);
      else if(m.type==="LOCK"){privateKey=null;publicKeyRaw=null;result={locked:true};}
      else if(m.type==="STATUS") result=await status();
      else if(m.type==="CONNECT"){
        const st=await status();
        if(!st.exists) throw new Error("Create an Invictus wallet first");
        if(st.locked) throw new Error("Unlock Invictus Wallet first");
        result={publicKey:st.publicKey};
      }
      else if(m.type==="SIGN_MESSAGE") result=await signMessage(m.message);
      else if(m.type==="SIGN_TRANSACTION") throw new Error("Transaction signing is disabled in V2 MVP until approval decoding is implemented");
      else throw new Error("Unknown request");
      reply({ok:true,result});
    }catch(e){reply({ok:false,error:e?.message||"Invictus Wallet error"});}
  })();
  return true;
});
