
const ALPHABET="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
export function base58(bytes){
  if(!bytes.length)return "";
  const digits=[0];
  for(let i=0;i<bytes.length;i++){
    let carry=bytes[i];
    for(let j=0;j<digits.length;j++){
      carry += digits[j]<<8;
      digits[j]=carry%58;
      carry=(carry/58)|0;
    }
    while(carry){digits.push(carry%58);carry=(carry/58)|0;}
  }
  let out="";
  for(let i=0;i<bytes.length&&bytes[i]===0;i++) out+=ALPHABET[0];
  for(let i=digits.length-1;i>=0;i--) out+=ALPHABET[digits[i]];
  return out;
}
