
const $=id=>document.getElementById(id);

function send(type,data={}){
  return new Promise((resolve,reject)=>{
    chrome.runtime.sendMessage({type,...data},r=>{
      if(chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if(!r?.ok) return reject(new Error(r?.error||"Invictus Wallet error"));
      resolve(r.result);
    });
  });
}

function toast(msg){
  $("toast").textContent=msg;$("toast").classList.remove("hidden");
  setTimeout(()=>$("toast").classList.add("hidden"),1800);
}

async function getSolBalance(address){
  try{
    const r=await fetch("https://api.mainnet-beta.solana.com",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({jsonrpc:"2.0",id:1,method:"getBalance",params:[address]})
    });
    const j=await r.json();
    return (j?.result?.value||0)/1e9;
  }catch{return 0;}
}

async function refresh(){
  try{
    const s=await send("STATUS");
    $("setupView").classList.toggle("hidden",s.exists);
    $("lockedView").classList.toggle("hidden",!s.exists||!s.locked);
    $("walletView").classList.toggle("hidden",!s.exists||s.locked);

    if(s.publicKey){
      $("shortAddress").textContent=s.publicKey.slice(0,6)+"..."+s.publicKey.slice(-6);
      $("receiveAddress").textContent=s.publicKey;
      if(!s.locked){
        const bal=await getSolBalance(s.publicKey);
        $("solBalance").textContent=bal.toFixed(4)+" SOL";
        $("solAssetBalance").textContent=bal.toFixed(4);
        $("usdBalance").textContent="$0.00";
      }
    }
  }catch(e){toast(e.message)}
}

$("createWallet").onclick=async()=>{
  try{
    await send("CREATE",{password:$("createPassword").value});
    $("createPassword").value="";toast("Wallet created");await refresh();
  }catch(e){toast(e.message)}
};

$("importWallet").onclick=async()=>{
  try{
    await send("IMPORT",{privateKey:$("importKey").value,password:$("createPassword").value});
    $("importKey").value="";$("createPassword").value="";toast("Wallet imported");await refresh();
  }catch(e){toast(e.message)}
};

$("unlockWallet").onclick=async()=>{
  try{
    await send("UNLOCK",{password:$("unlockPassword").value});
    $("unlockPassword").value="";await refresh();
  }catch(e){toast(e.message)}
};

$("lockWallet").onclick=async()=>{await send("LOCK");await refresh()};

$("copyAddress").onclick=async()=>{
  const s=await send("STATUS"); if(s.publicKey){await navigator.clipboard.writeText(s.publicKey);toast("Address copied")}
};
$("copyReceive").onclick=async()=>{
  const s=await send("STATUS"); if(s.publicKey){await navigator.clipboard.writeText(s.publicKey);toast("Address copied")}
};
$("receiveBtn").onclick=()=>$("receiveModal").classList.remove("hidden");
$("closeReceive").onclick=()=>$("receiveModal").classList.add("hidden");
$("sendBtn").onclick=()=>$("sendModal").classList.remove("hidden");
$("closeSend").onclick=()=>$("sendModal").classList.add("hidden");
$("settingsBtn").onclick=()=>toast("Invictus Wallet V2");

refresh();
