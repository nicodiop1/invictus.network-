INVICTUS WALLET V2 — READY TO LOAD

1. Extract the ZIP.
2. Open Chrome.
3. Go to chrome://extensions
4. Turn Developer mode ON.
5. Click Load unpacked.
6. Select the extracted Invictus-Wallet-V2 folder.

Website test:
window.invictus?.isInvictus
Expected:
true

Connect:
await window.invictus.connect()

SECURITY:
This is a development MVP, not an audited production wallet.
The private key is generated with browser Ed25519 WebCrypto and stored encrypted locally using PBKDF2 + AES-GCM.
Transaction signing is intentionally disabled until an explicit transaction approval/decoder flow is implemented.
Do not store meaningful funds in this build.
